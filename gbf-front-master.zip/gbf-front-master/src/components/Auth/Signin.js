import React, {Component} from 'react';
import { Button, Form, FormGroup,Input, Container, Row, Col } from 'reactstrap';
import './auth.css';

class Auth extends Component{
    render(){
        return (
            <Container className="cont">
                <Row>
                    <Col sm="8" md={{ size: 4, offset: 4 }}>
                        <Form>
                            <FormGroup>
                                <Input type="text" name="etablissement" id="username" placeholder="Etablissement" />
                            </FormGroup>
                            <FormGroup>
                                <Input type="password" name="password" id="examplePassword" placeholder="Mot de passe" />
                            </FormGroup>
                            <Button>Se connecter</Button>
                        </Form>
                    </Col>
                </Row>
            </Container>
        );
    }

}


export default Auth;
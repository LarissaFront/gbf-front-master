import React from 'react';
import Signin from './components/Auth/Signin';

function App() {
  return (
    <Signin/>
  );
}

export default App;
